#!/bin/sh
#DESCRIPTION=This script shows Network Interfaces Informations

ifconfig

echo ""
exit 0


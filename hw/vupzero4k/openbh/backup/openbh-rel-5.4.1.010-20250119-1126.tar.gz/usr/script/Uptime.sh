#!/bin/sh
#DESCRIPTION=This script will show you the uptime
uptime
echo ""
exit 0